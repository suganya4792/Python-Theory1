 #echo Hello World

chmod 755 ./run
#alias ./run ./run
python3 main.py