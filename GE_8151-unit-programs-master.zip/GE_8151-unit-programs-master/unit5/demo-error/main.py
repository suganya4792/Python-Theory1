print("\n DEMO ERRORS")
print("------------------")
a = 20

'''Original code by rajasekaranap, fails the build
if a < 30
print("a is less than 30")
'''
if a < 30:
    print("a is less than 30")
