rm *.txt
cp backup/*.txt .
echo $PWD
echo "RESET Completed" 
