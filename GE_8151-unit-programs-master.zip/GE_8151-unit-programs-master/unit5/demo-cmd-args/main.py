import sys
print("\n DEMO CMD LINE ARGS")
print("------------------")
args = sys.argv
print("Length of arguments:", len(args))
print("arguments:", args)
