fileToRead = open("source.txt", "r")
data = fileToRead.readlines()
print(data)
fileToRead.close()
