fileToRead = open("source.txt", "r")
data = fileToRead.read()
print(data)
fileToRead.close()
