rm *.txt
cp backup/*.txt .
echo "RESET Completed"