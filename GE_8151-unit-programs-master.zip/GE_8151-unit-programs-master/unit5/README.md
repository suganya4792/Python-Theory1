
# Legend 

Please find below the list of sub-directories for unit 5, and their intended purposes. 

## demo-read
## demo-read-with-size
## demo-readlines 


