import math
print("\n Build in Module")
print("------------------")
print("Cos 90 :", math.cos(90))
print("SQRT 48 :", math.sqrt(48))
