rm *.txt
echo $PWD
echo "RESET Completed" 
