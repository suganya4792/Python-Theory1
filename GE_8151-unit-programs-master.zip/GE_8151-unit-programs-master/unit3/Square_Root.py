# importing math module
import math
# Function definition


def square_root(n):
    a = math.sqrt(n)
    print('the square root of a number is ', a)


# Main program
n = int(input("enter a number:"))
square_root(n)
