

print()
print()
print()
print()
print()
print()
print()
print("------------ GE_8151 Python Programming -----------")


print("Unit 2 Illustrative Programs")
filenames = " \n\
  swap.py \n\
  circulate.py \n\
  distance.py \n\
"
print(filenames)
print("In the console, type")
print("cd unit2")
print("python3 <filename>")
print("  e.g. python3 circulate.py")
